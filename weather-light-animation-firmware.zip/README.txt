Weather Light Studio - Arduino firmware

For the existing Weather Light XIAO ESP32-C3 hardware. After you add
an animation, a tap on the rear Mode button cycles Weather, Clock,
Demo, and Custom. Custom loops your animation offline.

Install the Arduino IDE, then set up the board and libraries once

1. Add the board package URL in the IDE Preferences.
   https://espressif.github.io/arduino-esp32/package_esp32_index.json
2. In Boards Manager, install esp32 by Espressif Systems version 3.3.5.
   Select the XIAO_ESP32C3 board. Use the default 4 MB flash and
   partition options. Leave Erase All Flash Before Sketch Upload
   Disabled so regular uploads keep your saved Wi-Fi and location.
3. Install the listed versions from Library Manager.
   Adafruit NeoPixel 1.15.1
   Adafruit SSD1306 2.5.15
   Adafruit GFX Library 1.12.4
   Adafruit BusIO 1.17.4
   ArduinoJson 7.4.2

Install an animation

1. Unzip this download. Open WeatherLight/WeatherLight.ino in Arduino
   IDE. Use the complete WeatherLight folder with all its source files.
2. Open the editable JSON in Studio. Choose Export > For the Weather
   Light, and save CustomAnimation.h in the WeatherLight folder next
   to the .ino file. Keep the exact filename.
3. Unplug the rear 5V IN cable. Use a data-capable USB-C cable to connect
   the rear DATA port to your computer. Select its serial port in
   Arduino IDE, then upload the sketch.
4. After upload, unplug DATA before reconnecting 5V IN. Tap Mode until
   the OLED shows CUSTOM.

An export installs one looping animation. Replace CustomAnimation.h and
upload again to switch animations. Move the header out of the sketch
folder and upload again to remove Custom. Keep the editable JSON for
editing and sharing.

First-time Wi-Fi setup

Attach the XIAO radio antenna before powering the radio. Join the
temporary Wi-Fi network shown on the OLED and open http://192.168.4.1.
Enter your own 2.4 GHz Wi-Fi and town coordinates. Chicago is a generic
example for new setups. The supplied time zone is U.S. Central.
New uploads with erase disabled keep previously saved settings.
To play Custom before configuring Wi-Fi, hold Mode for 3 seconds to
close setup. Then tap Mode to reach Custom.

Weather data by Open-Meteo (https://open-meteo.com/).
