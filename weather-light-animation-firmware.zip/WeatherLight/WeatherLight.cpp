#include <Adafruit_SSD1306.h>
#include <Wire.h>
#include <driver/usb_serial_jtag.h>
#include <time.h>
#include "Forecast.h"
#include "Pixels.h"
#include "SetupPortal.h"

#if __has_include("CustomAnimation.h")
#include "CustomAnimation.h"
#define WEATHER_LIGHT_HAS_CUSTOM_ANIMATION 1
#else
#define WEATHER_LIGHT_HAS_CUSTOM_ANIMATION 0
#endif

namespace {
constexpr uint32_t WEATHER_REFRESH = 10 * 60 * 1000UL;
constexpr uint32_t WEATHER_RETRY = 60 * 1000UL;
constexpr uint32_t STALE_AFTER = 25 * 60 * 1000UL;
constexpr uint32_t EXPIRE_AFTER = 2 * 60 * 60 * 1000UL;
constexpr uint32_t WEATHER_CARD_TIME = 6000;
constexpr uint32_t MATRIX_WHITE_TIME = 30000;
constexpr uint32_t USB_PROBE_TIME = 600;
constexpr uint32_t CLOCK_SYNC_WAIT = 30000;
constexpr uint32_t STARTUP_PATTERN_TIME = 1800;
constexpr uint32_t REFRESH_PATTERN_DELAY = 1200;
constexpr uint32_t LOADING_PATTERN_TIME = 2400;
constexpr time_t EARLIEST_CLOCK = 1735689600;

enum class Mode {
  Weather, Clock, Demo,
#if WEATHER_LIGHT_HAS_CUSTOM_ANIMATION
  Custom,
#endif
  Count
};
struct DemoScene { int code; bool day; int temp; };
constexpr DemoScene scenes[] = {{0,true,74},{2,true,72},{3,true,64},{45,true,62},
                                {61,true,57},{95,true,68},{0,false,54},{2,false,48},
                                {66,true,31},{71,true,28}};

#if WEATHER_LIGHT_HAS_CUSTOM_ANIMATION
constexpr size_t CUSTOM_FRAME_COUNT =
    sizeof(custom_animation::frames) / sizeof(custom_animation::frames[0]);
static_assert(CUSTOM_FRAME_COUNT >= 1 && CUSTOM_FRAME_COUNT <= 120,
              "Weather Light custom animations support 1 to 120 frames.");
static_assert(CUSTOM_FRAME_COUNT ==
              sizeof(custom_animation::durations) / sizeof(custom_animation::durations[0]),
              "Provide one duration per custom frame.");

constexpr uint32_t customDuration() {
  uint32_t total = 0;
  for (const uint16_t duration : custom_animation::durations) {
    if (duration < 80 || duration > 10000) return 0;
    total += duration;
  }
  return total;
}

constexpr uint32_t CUSTOM_DURATION = customDuration();
static_assert(CUSTOM_DURATION > 0, "Custom frame durations must be 80 to 10000 ms.");

size_t customFrameAt(uint32_t elapsed) {
  uint32_t remaining = elapsed % CUSTOM_DURATION;
  size_t frame = 0;
  while (remaining >= custom_animation::durations[frame]) {
    remaining -= custom_animation::durations[frame++];
  }
  return frame;
}
#endif

Pixels pixels;
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
SetupPortal portal;
Mode mode = Mode::Weather;
Forecast lastWeather;
QueueHandle_t requestQueue = nullptr;
QueueHandle_t resultQueue = nullptr;
bool networkReady = false;
bool oledReady = false;
bool usbService = false;
bool bootDiagnostic = false;
MatrixTest matrixTest = MatrixTest::Corners;
uint32_t testSince = 0;
bool hasWeather = false;
bool weatherBusy = false;
bool weatherFailed = false;
bool startupPattern = false;
uint32_t startupSince = 0;
bool loadingPatternAllowed = false;
uint32_t loadingSince = 0;
uint32_t loadingDelay = 0;
Pattern loadingTheme = Pattern::Ripple;
Pattern nextLoadingTheme = Pattern::Ripple;
bool previousLink = false;
uint32_t linkSince = 0;
uint32_t generation = 0;
uint32_t triedAt = 0;
uint32_t attemptPeriod = 0;
uint32_t lastSuccess = 0;
uint32_t modeSince = 0;

void weatherWorker(void*) {
  WeatherRequest request{};
  for (;;) {
    if (xQueueReceive(requestQueue, &request, portMAX_DELAY) == pdTRUE) {
      WeatherResult result{};
      result.generation = request.generation;
      result.ok = requestForecast(request, result.forecast);
      xQueueOverwrite(resultQueue, &result);
    }
  }
}

void updateWeather(uint32_t now) {
  if (hasWeather && now - lastSuccess >= EXPIRE_AFTER) hasWeather = false;
  if (loadingPatternAllowed && now - loadingSince >= loadingDelay + LOADING_PATTERN_TIME) {
    loadingPatternAllowed = false;
  }

  if (generation != portal.generation()) {
    generation = portal.generation();
    hasWeather = false;
    weatherFailed = false;
    startupPattern = false;
    loadingPatternAllowed = false;
    attemptPeriod = 0;
    mode = Mode::Weather;
    modeSince = now;
  }

  WeatherResult result;
  if (networkReady && xQueueReceive(resultQueue, &result, 0) == pdTRUE) {
    weatherBusy = false;
    loadingPatternAllowed = false;
    if (result.generation == generation) {
      triedAt = now;
      attemptPeriod = result.ok ? WEATHER_REFRESH : WEATHER_RETRY;
      weatherFailed = !result.ok;
      if (result.ok) {
        if (!hasWeather && mode == Mode::Weather) modeSince = now;
        lastWeather = result.forecast;
        lastSuccess = now;
        hasWeather = true;
        Serial.printf("Weather received: %.1f F, WMO %d\n", lastWeather.temp, lastWeather.code);
      }
    }
  }
  const bool link = portal.configured() && !portal.active() && WiFi.status() == WL_CONNECTED;
  if (!link) loadingPatternAllowed = false;
  if (link && !previousLink) {
    linkSince = now;
    configTzTime(LOCAL_TZ, "time.cloudflare.com", "pool.ntp.org", "time.google.com");
    attemptPeriod = 0;
  }
  previousLink = link;
  if (networkReady && link && !weatherBusy && time(nullptr) >= EARLIEST_CLOCK &&
      now - triedAt >= attemptPeriod) {
    WeatherRequest request{portal.settings().lat, portal.settings().lon, generation};
    if (xQueueSend(requestQueue, &request, 0) == pdTRUE) {
      weatherBusy = true;
      loadingSince = now;
      loadingDelay = hasWeather ? REFRESH_PATTERN_DELAY : 0;
      loadingPatternAllowed = mode == Mode::Weather;
      loadingTheme = nextLoadingTheme;
      nextLoadingTheme = static_cast<Pattern>((static_cast<unsigned>(nextLoadingTheme) + 1) % 3);
    }
  }
}

void updateButton(uint32_t now) {
  static bool raw = digitalRead(MODE_PIN);
  static bool stable = raw;
  static bool handledHold = bootDiagnostic && stable == LOW;
  static uint32_t changedAt = 0;
  static uint32_t pressedAt = now;

  const bool reading = digitalRead(MODE_PIN);
  if (reading != raw) {
    raw = reading;
    changedAt = now;
  }
  if (raw != stable && now - changedAt >= 30) {
    stable = raw;
    if (stable == LOW) {
      pressedAt = now;
      handledHold = false;
    } else if (!handledHold) {
      if (bootDiagnostic) {
        matrixTest = static_cast<MatrixTest>((static_cast<unsigned>(matrixTest) + 1) % 3);
        testSince = now;
      } else if (!portal.active()) {
        startupPattern = false;
        loadingPatternAllowed = false;
        mode = static_cast<Mode>((static_cast<unsigned>(mode) + 1) %
                                 static_cast<unsigned>(Mode::Count));
        modeSince = now;
      }
    }
  }
  if (stable == LOW && !handledHold && now - pressedAt >= 3000) {
    handledHold = true;
    if (bootDiagnostic) return;
    startupPattern = false;
    loadingPatternAllowed = false;
    if (portal.active()) portal.cancel(now);
    else portal.open(now);
  }
}

void textAt(int x, int y, const char* value, uint8_t size = 1) {
  oled.setTextSize(size);
  oled.setCursor(x, y);
  oled.print(value);
}

void header(const char* title, bool online = false) {
  textAt(0, 0, title);
  if (online) {
    oled.fillCircle(113, 4, 1, SSD1306_WHITE);
    oled.fillCircle(119, 4, 1, SSD1306_WHITE);
    oled.fillCircle(125, 4, 1, SSD1306_WHITE);
  }
  oled.drawFastHLine(0, 11, 128, SSD1306_WHITE);
}

void enterUSBService() {
  // A suspended USB host can stop sending frames while DATA still powers the board.
  // Latch service mode until the next reset.
  usbService = true;
  pinMode(LED_DATA_PIN, INPUT_PULLDOWN);
  WiFi.mode(WIFI_OFF);
  Serial.println("USB DATA service mode. Matrix data and Wi-Fi are idle until reset.");
  if (oledReady) {
    oled.dim(false);
    oled.clearDisplay();
    header("USB DATA");
    textAt(0, 24, "Ready for updates");
    textAt(0, 40, "Unplug DATA to exit");
    oled.display();
  }
}

void temperatureLabel(float temp, char* output, size_t capacity) {
  if (isfinite(temp)) snprintf(output, capacity, "%.0f", fabsf(temp) < 0.5f ? 0 : temp);
  else strlcpy(output, "--", capacity);
}

void drawTemperature(int x, int y, float value, uint8_t size) {
  char rounded[8];
  temperatureLabel(value, rounded, sizeof(rounded));
  textAt(x, y, rounded, size);
  if (isfinite(value)) {
    const int suffix = x + strlen(rounded) * 6 * size;
    oled.drawCircle(suffix + 3, y + 3, 2, SSD1306_WHITE);
    textAt(suffix + 8, y + 2, "F", size > 2 ? 2 : 1);
  }
}

void drawWeather(const Forecast& forecast, bool stale, bool isDemo, bool details, uint32_t age) {
  header(isDemo ? "DEMO" : portal.settings().place, !isDemo && previousLink);
  if (details) {
    textAt(0, 17, "HIGH");
    textAt(66, 17, "LOW");
    oled.drawFastVLine(63, 17, 29, SSD1306_WHITE);
    drawTemperature(0, 29, forecast.high, 2);
    drawTemperature(66, 29, forecast.low, 2);
    char rain[21] = "PRECIP MAX --";
    if (forecast.rain >= 0) snprintf(rain, sizeof(rain), "PRECIP MAX %d%%", forecast.rain);
    textAt(0, 48, rain);
  } else {
    drawTemperature(0, 17, forecast.temp, 4);
    if (stale) {
      char label[22];
      snprintf(label, sizeof(label), "STALE / %lu min ago", static_cast<unsigned long>(age / 60000));
      textAt(0, 48, label);
    } else {
      textAt(0, 48, conditionFor(forecast.code, forecast.day).label);
    }
  }
  if (!isDemo) textAt(0, 56, "Open-Meteo");
}

bool drawPattern(uint32_t now, uint8_t brightness) {
  if (startupPattern && now - startupSince < STARTUP_PATTERN_TIME) {
    pixels.pattern(now - startupSince, brightness, Pattern::Aurora);
    return true;
  }
  const uint32_t age = now - loadingSince;
  if (weatherBusy && loadingPatternAllowed && age >= loadingDelay &&
      age - loadingDelay < LOADING_PATTERN_TIME) {
    pixels.pattern(age - loadingDelay, brightness, loadingTheme);
    return true;
  }
  return false;
}

void render(uint32_t now, bool refreshOled) {
  tm clock{};
  const time_t utc = time(nullptr);
  const bool timed = utc >= EARLIEST_CLOCK && localtime_r(&utc, &clock);
  const bool quietHours = timed && (clock.tm_hour >= 22 || clock.tm_hour < 6);
  uint8_t brightness = quietHours ? NIGHT_BRIGHTNESS : DAY_BRIGHTNESS;
  if (refreshOled) {
    oled.clearDisplay();
    static bool dimmed = false;
    const bool shouldDim = quietHours && !portal.active();
    if (dimmed != shouldDim) {
      oled.dim(shouldDim);
      dimmed = shouldDim;
    }
  }

  if (bootDiagnostic) {
    if (matrixTest == MatrixTest::White && now - testSince >= MATRIX_WHITE_TIME) {
      matrixTest = MatrixTest::Corners;
    }
    pixels.diagnostic(now - testSince, matrixTest);
    if (refreshOled) {
      header("MATRIX TEST");
      if (matrixTest == MatrixTest::White) {
        char timeLeft[22];
        snprintf(timeLeft, sizeof(timeLeft), "White at cap / %lus",
                 static_cast<unsigned long>((MATRIX_WHITE_TIME - (now - testSince) + 999) / 1000));
        textAt(0, 19, timeLeft);
      } else if (matrixTest == MatrixTest::Scan) {
        char pixel[22];
        snprintf(pixel, sizeof(pixel), "Raw pixel %lu / 63",
                 static_cast<unsigned long>(((now - testSince) / 240) % 64));
        textAt(0, 19, pixel);
      } else {
        textAt(0, 19, "R/G top   B/W bottom");
      }
      textAt(0, 37, "Tap: change test");
      textAt(0, 54, "Power cycle: exit");
    }
  } else if (portal.active()) {
    pixels.status(now, true, 20);
    if (refreshOled) {
      header("WI-FI SETUP");
      if (portal.joining() || portal.saved()) {
        textAt(0, 21, portal.saved() ? "Connected!" : "Joining home Wi-Fi");
        textAt(0, 54, portal.saved() ? "Loading weather..." : "One moment...");
      } else {
        char passLine[22];
        snprintf(passLine, sizeof(passLine), "Password %s", portal.setupPassword());
        textAt(0, 18, portal.setupSSID());
        textAt(0, 30, passLine);
        textAt(0, 42, "http://192.168.4.1");
        textAt(0, 54, portal.message()[0] ? "Check setup page" : "Join setup Wi-Fi");
      }
    }
  } else if (mode == Mode::Demo) {
    const DemoScene& scene = scenes[((now - modeSince) / 5700) % (sizeof(scenes) / sizeof(*scenes))];
    Forecast sample;
    sample.code = scene.code;
    sample.temp = scene.temp;
    sample.day = scene.day;
    pixels.sky(conditionFor(sample.code, sample.day).sky, now, brightness);
    if (refreshOled) drawWeather(sample, false, true, false, 0);
#if WEATHER_LIGHT_HAS_CUSTOM_ANIMATION
  } else if (mode == Mode::Custom) {
    pixels.customFrame(custom_animation::frames[customFrameAt(now - modeSince)], brightness);
    if (refreshOled) {
      header("CUSTOM");
      textAt(0, 24, "Looping animation");
      textAt(0, 54, "Tap Mode to exit");
    }
#endif
  } else if (mode == Mode::Clock && timed) {
    pixels.clock(clock.tm_hour, clock.tm_min, brightness);
    if (refreshOled) {
      char message[24];
      header("LOCAL TIME", previousLink);
      const unsigned hour = clock.tm_hour % 12 ? clock.tm_hour % 12 : 12;
      snprintf(message, sizeof(message), "%u:%02d", hour, clock.tm_min);
      textAt(0, 20, message, 3);
      textAt(strlen(message) * 18 + 4, 32, clock.tm_hour < 12 ? "AM" : "PM");
      strftime(message, sizeof(message), "%a %b %d", &clock);
      textAt(0, 54, message);
    }
  } else if (mode == Mode::Weather && hasWeather) {
    const uint32_t age = now - lastSuccess;
    const bool stale = age >= STALE_AFTER;
    if (stale && brightness > 18) brightness = 18;
    if (!drawPattern(now, brightness)) {
      pixels.sky(conditionFor(lastWeather.code, lastWeather.day).sky, now, brightness, stale);
    }
    if (refreshOled) {
      char today[11]{};
      if (timed) strftime(today, sizeof(today), "%Y-%m-%d", &clock);
      const bool hasDaily = isfinite(lastWeather.high) || isfinite(lastWeather.low) || lastWeather.rain >= 0;
      const bool details = !stale && timed && hasDaily && strcmp(today, lastWeather.forecastDate) == 0 &&
                           (now - modeSince) / WEATHER_CARD_TIME % 2 == 1;
      drawWeather(lastWeather, stale, false, details, age);
    }
  } else {
    if (mode != Mode::Weather || !drawPattern(now, brightness)) {
      pixels.status(now, false, brightness);
    }
    if (refreshOled) {
      header(mode == Mode::Clock ? "LOCAL TIME" : portal.settings().place, previousLink);
      const bool clockDelayed = previousLink && !timed && now - linkSince >= CLOCK_SYNC_WAIT;
      const char* status = "Waiting for weather";
      const char* hint = "Hold Mode for setup";
      if (!portal.configured()) status = "Set up Wi-Fi";
      else if (!previousLink) status = "Wi-Fi offline";
      else if (!timed) {
        status = clockDelayed ? "Clock not synced" : "Syncing clock";
        if (clockDelayed) hint = "Check internet / NTP";
      } else if (!networkReady) {
        status = "Restart to retry";
      } else if (weatherBusy) {
        status = "Getting weather";
      } else if (weatherFailed) {
        status = "Weather unavailable";
        hint = "Retrying in a minute";
      }
      textAt(0, 24, status);
      textAt(0, 54, hint);
    }
  }
  if (refreshOled) oled.display();
}
}  // namespace

void setup() {
  pinMode(LED_DATA_PIN, INPUT_PULLDOWN);
  Serial.begin(115200);
  pinMode(MODE_PIN, INPUT_PULLUP);
  delay(45);
  bootDiagnostic = digitalRead(MODE_PIN) == LOW;
  const uint32_t probeStarted = millis();
  bool hostDetected = usb_serial_jtag_is_connected();
  Wire.begin(OLED_SDA, OLED_SCL);
  Wire.setClock(100000);
  for (uint8_t address : {0x3C, 0x3D}) {
    Wire.beginTransmission(address);
    if (Wire.endTransmission() == 0 && oled.begin(SSD1306_SWITCHCAPVCC, address, false, false)) {
      oledReady = true;
      oled.setTextColor(SSD1306_WHITE);
      oled.setTextWrap(false);
      Serial.printf("OLED at 0x%02X\n", address);
      break;
    }
  }
  if (!oledReady) Serial.println("SSD1306 OLED not found at 0x3C or 0x3D.");
  while (!hostDetected && millis() - probeStarted < USB_PROBE_TIME) {
    hostDetected = usb_serial_jtag_is_connected();
    delay(5);
  }
  Serial.println("Weather Light 2.6");
  if (hostDetected || usb_serial_jtag_is_connected()) {
    enterUSBService();
    return;
  }
  pixels.begin();
  if (bootDiagnostic) {
    Serial.println("Matrix diagnostic. Tap Mode for corners, raw scan or full white. Power cycle to exit.");
    return;
  }
  portal.begin();
  startupSince = millis();
  startupPattern = !portal.active();
  requestQueue = xQueueCreate(1, sizeof(WeatherRequest));
  resultQueue = xQueueCreate(1, sizeof(WeatherResult));
  networkReady = requestQueue && resultQueue &&
                 xTaskCreate(weatherWorker, "weather", 12288, nullptr, 1, nullptr) == pdPASS;
}

void loop() {
  if (!usbService && usb_serial_jtag_is_connected()) enterUSBService();
  if (usbService) {
    delay(20);
    return;
  }
  static uint32_t lastFrame = 0;
  static uint32_t lastOled = 0;
  uint32_t now = millis();
  if (startupPattern && now - startupSince >= STARTUP_PATTERN_TIME) startupPattern = false;
  updateButton(now);
  if (!bootDiagnostic) {
    portal.update(now);
    now = millis();
    updateWeather(now);
  }
  bool frameDue = now - lastFrame >= 80;
#if WEATHER_LIGHT_HAS_CUSTOM_ANIMATION
  static size_t lastCustomFrame = CUSTOM_FRAME_COUNT;
  if (mode == Mode::Custom && !portal.active()) {
    // Draw at frame boundaries even when they fall between the usual 80 ms ticks.
    const size_t nextFrame = customFrameAt(now - modeSince);
    frameDue = frameDue || nextFrame != lastCustomFrame;
    lastCustomFrame = nextFrame;
  } else {
    lastCustomFrame = CUSTOM_FRAME_COUNT;
  }
#endif
  if (frameDue) {
    lastFrame = now;
    const uint32_t oledInterval = matrixTest == MatrixTest::Scan ? 120 : 400;
    const bool refresh = oledReady && now - lastOled >= oledInterval;
    if (refresh) lastOled = now;
    render(now, refresh);
  }
  delay(3);
}
