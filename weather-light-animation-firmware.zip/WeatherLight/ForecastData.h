#pragma once
#include <ArduinoJson.h>
#include <math.h>
#include <string.h>

struct Forecast {
  float temp = 0;
  float high = NAN;
  float low = NAN;
  int rain = -1;
  int code = -1;
  bool day = true;
  char forecastDate[11]{};
};

inline float temperatureF(JsonVariantConst value) {
  const float degrees = value | NAN;
  return isfinite(degrees) && degrees >= -130 && degrees <= 150 ? degrees : NAN;
}

template <typename Input>
bool readForecast(Input& payload, Forecast& forecast) {
  JsonDocument filter;
  filter["current"]["temperature_2m"] = true;
  filter["current"]["weather_code"] = true;
  filter["current"]["is_day"] = true;
  filter["daily"]["time"][0] = true;
  filter["daily"]["temperature_2m_max"][0] = true;
  filter["daily"]["temperature_2m_min"][0] = true;
  filter["daily"]["precipitation_probability_max"][0] = true;

  JsonDocument document;
  const auto error = deserializeJson(document, payload, DeserializationOption::Filter(filter));
  if (error) return false;

  Forecast parsed;
  parsed.temp = temperatureF(document["current"]["temperature_2m"]);
  parsed.code = document["current"]["weather_code"] | -1;
  const int dayValue = document["current"]["is_day"] | -1;
  if (!isfinite(parsed.temp) || parsed.code < 0 || parsed.code > 99 ||
      (dayValue != 0 && dayValue != 1)) return false;

  parsed.day = dayValue == 1;
  const char* date = document["daily"]["time"][0] | "";
  if (strlen(date) == 10) memcpy(parsed.forecastDate, date, 10);
  parsed.high = temperatureF(document["daily"]["temperature_2m_max"][0]);
  parsed.low = temperatureF(document["daily"]["temperature_2m_min"][0]);
  if (parsed.high < parsed.low) parsed.high = parsed.low = NAN;
  parsed.rain = document["daily"]["precipitation_probability_max"][0] | -1;
  if (parsed.rain < 0 || parsed.rain > 100) parsed.rain = -1;
  forecast = parsed;
  return true;
}

