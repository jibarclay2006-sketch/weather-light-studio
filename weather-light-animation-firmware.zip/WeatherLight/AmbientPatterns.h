#pragma once

#include <math.h>
#include <stdint.h>

enum class Pattern { Aurora, Ripple, Spiral };

namespace ambient {
struct Light {
  float r, g, b;

  Light operator+(const Light& other) const {
    return {r + other.r, g + other.g, b + other.b};
  }

  Light operator*(float amount) const {
    return {r * amount, g * amount, b * amount};
  }
};

constexpr float TURN = 6.283185307f;

inline float unit(float value) {
  return fminf(1, fmaxf(0, value));
}

inline float band(float distance, float width) {
  const float position = distance / width;
  return expf(-0.5f * position * position);
}

inline uint8_t channel(float value) {
  return static_cast<uint8_t>(unit(value) * 255 + 0.5f);
}

inline Light aurora(float x, float y, float time) {
  constexpr Light teal{.110874f, 1, .706705f};
  constexpr Light cyan{.085443f, .657492f, 1};
  constexpr Light lavender{.571529f, .296470f, .945532f};
  constexpr Light blue{.166957f, .344040f, 1};
  const float angle = time * TURN / 6;
  const float crest = -.64f + 1.38f * sinf(x * .64f + angle) +
                      .34f * sinf(x * 1.21f - angle);
  const float mix = .5f + .5f * cosf(x * .48f + angle);
  const Light ribbon = teal * mix + cyan * (1 - mix);
  return ribbon * (.97f * band(y - crest, .61f)) +
         lavender * (.65f * band(y - crest - 1.39f, .62f)) +
         blue * (.40f * band(y - crest + .97f, .48f));
}

inline Light ripple(float x, float y, float time) {
  constexpr Light gold{1, .696781f, .323974f};
  constexpr Light rose{.865491f, .239964f, .590333f};
  constexpr Light orange{1, .406247f, .163674f};
  constexpr Light peach{1, .726672f, .566855f};
  const float crest = fmodf(time * 1.64f + 1.78f, 8.3f);
  const float distance = fabsf(x) + fabsf(y) - crest;
  const float fade = unit((8.3f - crest) / 1.50f);
  const float seed = expf(-(x * x + y * y) / 1.35f) *
                     (.30f + .16f * sinf(time * 1.7f));
  return gold * (fade * band(distance, .55f)) +
         rose * (.64f * fade * band(distance + 1, .48f)) +
         orange * (.27f * fade * band(distance - 1, .51f)) + peach * seed;
}

inline Light spiral(float x, float y, float time) {
  constexpr Light purple{.736714f, .327960f, 1};
  constexpr Light pink{1, .344040f, .539045f};
  constexpr Light periwinkle{.381011f, .475742f, 1};
  constexpr Light pearl{1, .662367f, .813271f};
  const float angle = time * TURN / 8;
  const float radiusSquared = x * x + y * y;
  const float radius = sqrtf(radiusSquared);
  const float theta = atan2f(y, x);
  const float edge = (radius - 2.34f) / 1.99f;
  const float falloff = expf(-edge * edge * edge * edge);
  const float twist = (theta - .65f * radius - angle) * 2;
  const float arm = powf(unit((cosf(twist) + .29f) / 1.29f), 1.62f);
  const float trail = powf(unit((cosf(twist + .77f) + .10f) / 1.10f), 1.40f);
  const float mix = .5f + .5f * sinf(theta - angle - .18f * radius);
  const Light ramp = purple * mix + pink * (1 - mix);
  return ramp * (.88f * arm * falloff) + periwinkle * (.37f * trail * falloff) +
         pearl * (.68f * expf(-radiusSquared / 1.20f));
}
}  // namespace ambient
