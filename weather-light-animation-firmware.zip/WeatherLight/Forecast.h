#pragma once
#include "ForecastData.h"
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include "Settings.h"
#include "WeatherRoots.h"

struct WeatherRequest {
  float lat;
  float lon;
  uint32_t generation;
};

struct WeatherResult {
  Forecast forecast;
  uint32_t generation;
  bool ok;
};

inline bool requestForecast(const WeatherRequest& request, Forecast& forecast) {
  char url[370];
  snprintf(url, sizeof(url),
           "https://api.open-meteo.com/v1/forecast?latitude=%.5f&longitude=%.5f"
           "&current=temperature_2m,weather_code,is_day"
           "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max"
           "&temperature_unit=fahrenheit&timezone=%s&forecast_days=1",
           request.lat, request.lon, FORECAST_TZ);
  WiFiClientSecure connection;
  connection.setCACert(WEATHER_ROOTS);
  connection.setHandshakeTimeout(6);
  HTTPClient http;
  http.useHTTP10(true);
  http.setConnectTimeout(4500);
  http.setTimeout(4500);
  if (!http.begin(connection, url)) return false;
  const int code = http.GET();
  const bool ok = code == HTTP_CODE_OK && readForecast(http.getStream(), forecast);
  if (code != HTTP_CODE_OK) {
    Serial.printf("Open-Meteo request failed (HTTP result %d).\n", code);
  } else if (!ok) {
    Serial.println("Open-Meteo returned invalid weather data.");
  }
  http.end();
  return ok;
}
