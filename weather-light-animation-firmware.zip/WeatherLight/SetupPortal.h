#pragma once
#include <Preferences.h>
#include <WebServer.h>
#include <WiFi.h>
#include <esp_system.h>
#include "Settings.h"

struct Config {
  uint32_t magic = 0x574C0001;
  char ssid[33]{};
  char password[65]{};
  char place[19]{};
  float lat = DEFAULT_LAT;
  float lon = DEFAULT_LON;
};

class SetupPortal {
 public:
  void begin() {
    prefs.begin("weatherlight", false);
    strlcpy(config.place, DEFAULT_PLACE, sizeof(config.place));
    Config saved;
    if (prefs.getBytesLength("setup") == sizeof(saved) &&
        prefs.getBytes("setup", &saved, sizeof(saved)) == sizeof(saved) &&
        saved.magic == config.magic && saved.ssid[32] == 0 && saved.password[64] == 0 &&
        saved.place[18] == 0 && saved.ssid[0] != 0 &&
        isfinite(saved.lat) && fabs(saved.lat) <= 90 &&
        isfinite(saved.lon) && fabs(saved.lon) <= 180) {
      config = saved;
    }

    WiFi.persistent(false);
    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(true);
    server.on("/", HTTP_GET, [this] { page(); });
    server.on("/save", HTTP_POST, [this] { save(); });
    server.onNotFound([this] { page(); });
    if (configured()) join(millis());
    else open(millis());
  }

  bool configured() const { return config.ssid[0] != 0; }
  bool active() const { return isOpen; }
  bool joining() const { return isJoining; }
  bool saved() const { return closeAt != 0; }
  const Config& settings() const { return config; }
  uint32_t generation() const { return revision; }
  const char* setupSSID() const { return apSSID; }
  const char* setupPassword() const { return apPassword; }
  const char* message() const { return status; }

  void open(uint32_t now) {
    WiFi.setAutoReconnect(false);
    WiFi.disconnect();
    WiFi.mode(WIFI_AP_STA);
    snprintf(apSSID, sizeof(apSSID), "WeatherLight-%04lX",
             static_cast<unsigned long>(ESP.getEfuseMac() & 0xFFFF));
    snprintf(apPassword, sizeof(apPassword), "%08lu",
             static_cast<unsigned long>(esp_random() % 100000000UL));
    snprintf(token, sizeof(token), "%08lx%08lx",
             static_cast<unsigned long>(esp_random()), static_cast<unsigned long>(esp_random()));
    if (!WiFi.softAP(apSSID, apPassword, 1, 0, 2)) {
      WiFi.mode(WIFI_STA);
      WiFi.setAutoReconnect(true);
      join(now);
      Serial.println("Setup access point failed. Hold Mode to retry.");
      return;
    }
    isOpen = true;
    openedAt = now;
    closeAt = 0;
    isJoining = false;
    status = "";
    candidate = config;
    server.begin();
    Serial.printf("Setup Wi-Fi: %s | password: %s | http://192.168.4.1\n", apSSID, apPassword);
  }

  void cancel(uint32_t now) {
    if (!closeAt) close(now, false);
  }

  void update(uint32_t now) {
    if (!isOpen) {
      if (configured() && WiFi.status() != WL_CONNECTED && now - joinedAt >= 30000) join(now);
      return;
    }

    server.handleClient();
    now = millis();
    if (isJoining) {
      if (now - connectingAt >= 700 && WiFi.status() == WL_CONNECTED &&
          WiFi.SSID() == candidate.ssid && WiFi.localIP() != IPAddress(0, 0, 0, 0)) {
        isJoining = false;
        if (prefs.putBytes("setup", &candidate, sizeof(candidate)) != sizeof(candidate)) {
          WiFi.disconnect();
          status = "Settings could not be saved. Try again.";
          return;
        }
        config = candidate;
        ++revision;
        status = "Connected. Rejoin your home Wi-Fi and watch the display.";
        closeAt = millis();
      } else if (now - connectingAt > 20000) {
        WiFi.disconnect();
        isJoining = false;
        status = "Wi-Fi join failed. Check the network name and password.";
      }
    }
    if (closeAt) {
      if (millis() - closeAt >= 4000) close(now, true);
    } else if (!isJoining && now - openedAt > (configured() ? 300000UL : 900000UL)) {
      close(now, false);
    }
  }

 private:
  Preferences prefs;
  WebServer server{80};
  Config config;
  Config candidate;
  bool isOpen = false;
  bool isJoining = false;
  uint32_t revision = 0;
  uint32_t openedAt = 0;
  uint32_t connectingAt = 0;
  uint32_t closeAt = 0;
  uint32_t joinedAt = 0;
  char apSSID[19]{};
  char apPassword[9]{};
  char token[17]{};
  const char* status = "";

  void join(uint32_t now) {
    joinedAt = now;
    if (configured()) WiFi.begin(config.ssid, config.password[0] ? config.password : nullptr);
  }

  void close(uint32_t now, bool keepConnection) {
    server.stop();
    WiFi.softAPdisconnect(false);
    WiFi.mode(WIFI_STA);
    isOpen = false;
    isJoining = false;
    closeAt = 0;
    candidate = Config{};
    WiFi.setAutoReconnect(true);
    if (!keepConnection) {
      WiFi.disconnect();
      join(now);
    }
  }

  bool fromSetupNetwork() {
    return isOpen && server.client().localIP() == WiFi.softAPIP();
  }

  static bool coordinate(String value, float limit, float& result) {
    value.trim();
    if (value.isEmpty() || value.length() > 15) return false;
    char* end = nullptr;
    const float parsed = strtof(value.c_str(), &end);
    if (end == value.c_str() || *end || !isfinite(parsed) || fabsf(parsed) > limit) return false;
    result = parsed;
    return true;
  }

  static String html(const String& input) {
    String output;
    for (size_t i = 0; i < input.length(); ++i) {
      const char ch = input[i];
      switch (ch) {
        case '&': output += "&amp;"; break;
        case '<': output += "&lt;"; break;
        case '>': output += "&gt;"; break;
        case '"': output += "&quot;"; break;
        case 39: output += "&#39;"; break;
        default: output += ch; break;
      }
    }
    return output;
  }

  void page() {
    if (!fromSetupNetwork()) {
      server.send(403, "text/plain", "Join the Weather Light setup Wi-Fi.");
      return;
    }
    const Config& shown = candidate.ssid[0] ? candidate : config;
    String body = F(R"HTML(<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Weather Light setup</title>)HTML");
    body.reserve(3800);
    if (isJoining) body += F("<meta http-equiv='refresh' content='2;url=/'>");
    body += F(R"HTML(<style>
*{box-sizing:border-box}
body{margin:0;background:#ebe5d9;color:#222925;font:16px/1.5 system-ui,sans-serif}
main{max-width:32rem;margin:1rem auto;padding:1rem}
header{background:#222925;color:#faf4e8;padding:1.5rem;border-radius:1rem 1rem 0 0}
header p{margin:0;color:#e3d6bb}h1{margin:0;font-size:2rem;line-height:1.25}
section{padding:1.5rem;background:#fbf7ef;border-radius:0 0 1rem 1rem}
p{margin:0 0 1rem}p.hint{font-size:.875rem;color:#515b54}
.status{padding:.75rem;background:#eee5cc;border-radius:.4rem}
fieldset{border:0;margin:0;padding:0;min-width:0}
fieldset+fieldset{border-top:1px solid #d6cdbd;margin-top:1.1rem;padding-top:.2rem}
label{display:block;margin:.8rem 0 .45rem;font-weight:600}
input,button{font:inherit;width:100%;padding:.6rem .7rem;border-radius:.4rem}
input{display:block;margin-top:.25rem;background:white;border:1px solid #a8ada3;color:#222925}
.checkbox{display:flex;gap:.55rem;align-items:flex-start;font-size:.875rem;font-weight:400}
.checkbox input{width:auto;margin-top:.27rem;accent-color:#294d45}
input:focus-visible,button:focus-visible{outline:2px solid #346760;outline-offset:2px}
.coords{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}
button{border:0;background:#294d45;color:white;margin-top:.7rem;font-weight:650}
</style>
<main><header><h1>Weather Light</h1><p>Wi-Fi &amp; location</p></header><section>)HTML");
    if (status[0]) {
      body += F("<p class='status' role='status'>");
      body += status;
      body += F("</p>");
    }
    if (!isJoining && !closeAt) {
      body += F("<p>Use your 2.4 GHz home network. Forecasts and the clock use Central Time.</p>"
                "<form method='post' action='/save'><input type='hidden' name='token' value='");
      body += token;
      body += F("'><fieldset><label>Wi-Fi name<input name='ssid' required maxlength='32' "
                "autocapitalize='none' spellcheck='false' value='");
      body += html(shown.ssid);
      body += F("'></label><label>Wi-Fi password<input name='password' type='password' "
                "autocomplete='new-password' maxlength='63'></label>");
      if (config.password[0]) {
        body += F("<label class='checkbox'><input type='checkbox' name='keep' checked>"
                  "Reuse the saved password if the Wi-Fi name is unchanged and the password box is empty.</label>");
      } else {
        body += F("<p class='hint'>Leave the password empty for an open network.</p>");
      }
      body += F("</fieldset><fieldset><label>Town label<input name='place' required maxlength='18' value='");
      body += html(shown.place);
      body += F("'></label><div class='coords'><label>Latitude<input name='lat' type='number' "
                "step='any' min='-90' max='90' required value='");
      body += String(shown.lat, 5);
      body += F("'></label><label>Longitude<input name='lon' type='number' step='any' "
                "min='-180' max='180' required value='");
      body += String(shown.lon, 5);
      body += F("'></label></div><p class='hint'>Copy the two decimal coordinates from a map pin. "
                "Keep the minus sign for west longitude.</p></fieldset><button>Save and connect</button></form>");
    } else if (isJoining) {
      body += F("<p>This page refreshes while the light joins your home network. "
                "Watch the display if your phone leaves the setup network.</p>");
    }
    body += F("</section></main></html>");
    server.sendHeader("Cache-Control", "no-store");
    server.send(200, "text/html; charset=utf-8", body);
  }

  void save() {
    if (!fromSetupNetwork() || server.arg("token") != token) {
      server.send(403, "text/plain", "Open the setup page again from the light's Wi-Fi.");
      return;
    }
    if (isJoining || closeAt) {
      page();
      return;
    }

    const String ssid = server.arg("ssid");
    String pass = server.arg("password");
    if (pass.isEmpty() && server.hasArg("keep") && ssid == config.ssid) pass = config.password;
    String place = server.arg("place");
    place.trim();
    bool printable = true;
    for (size_t i = 0; i < place.length(); ++i)
      if (place[i] < 32 || place[i] > 126) printable = false;

    Config submitted;
    if (ssid.isEmpty() || ssid.length() > 32 ||
        (!pass.isEmpty() && pass.length() < 8) || pass.length() > 63 ||
        place.isEmpty() || place.length() > 18 || !printable ||
        !coordinate(server.arg("lat"), 90, submitted.lat) ||
        !coordinate(server.arg("lon"), 180, submitted.lon)) {
      status = "Check the Wi-Fi name, password (8-63 characters, or blank), town label, and coordinates.";
      page();
      return;
    }

    strlcpy(submitted.ssid, ssid.c_str(), sizeof(submitted.ssid));
    strlcpy(submitted.password, pass.c_str(), sizeof(submitted.password));
    strlcpy(submitted.place, place.c_str(), sizeof(submitted.place));
    candidate = submitted;
    status = "Joining your home Wi-Fi...";
    isJoining = true;
    openedAt = millis();
    server.sendHeader("Cache-Control", "no-store");
    server.sendHeader("Location", "/");
    server.send(303);
    WiFi.disconnect();
    WiFi.begin(candidate.ssid, candidate.password[0] ? candidate.password : nullptr);
    connectingAt = millis();
  }
};
