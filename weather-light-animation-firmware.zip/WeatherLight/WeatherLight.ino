// Arduino entry point. setup() and loop() are defined in WeatherLight.cpp.
