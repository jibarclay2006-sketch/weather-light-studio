#pragma once
#include "AmbientPatterns.h"
#include "Settings.h"
#include <Adafruit_NeoPixel.h>

enum class Sky { Sun, Moon, Partly, PartlyNight, Cloud, Fog, Rain, Ice, Snow, Storm, Unknown };
enum class MatrixTest { Corners, Scan, White };

struct Condition {
  Sky sky;
  const char* label;
};

inline Condition conditionFor(int code, bool day) {
  switch (code) {
    case 0: case 1:
      return day ? Condition{Sky::Sun, "Clear"} : Condition{Sky::Moon, "Clear night"};
    case 2:
      return {day ? Sky::Partly : Sky::PartlyNight, "Partly cloudy"};
    case 3:
      return {Sky::Cloud, "Overcast"};
    case 45: case 48:
      return {Sky::Fog, "Fog"};
    case 51: case 53: case 55:
      return {Sky::Rain, "Drizzle"};
    case 61: case 63: case 65:
      return {Sky::Rain, "Rain"};
    case 80: case 81: case 82:
      return {Sky::Rain, "Showers"};
    case 56: case 57:
      return {Sky::Ice, "Freezing drizzle"};
    case 66: case 67:
      return {Sky::Ice, "Freezing rain"};
    case 71: case 73: case 75: case 77: case 85: case 86:
      return {Sky::Snow, "Snow"};
    case 95: case 96: case 97: case 99:
      return {Sky::Storm, "Thunderstorm"};
    default:
      return {Sky::Unknown, "Unknown weather"};
  }
}

class Pixels {
 public:
  void begin() {
    strip.begin();
    strip.clear();
    strip.show();
  }

  void sky(Sky kind, uint32_t now, uint8_t brightness, bool stale = false) {
    reset(brightness);
    const unsigned step = now / 240;
    switch (kind) {
      case Sky::Sun:
        paintSun(step);
        break;
      case Sky::Moon:
        paint(moon);
        point(6, 2, 173, 215, 255);
        if (step % 12 < 3) {
          point(6, 1, 97, 140, 229);
          point(5, 2, 97, 140, 229);
          point(7, 2, 97, 140, 229);
          point(6, 3, 97, 140, 229);
        }
        break;
      case Sky::Partly:
      case Sky::PartlyNight:
        paint(kind == Sky::Partly ? smallSun : smallMoon);
        paint(lowCloud, step % 16 >= 8 ? 1 : 0);
        break;
      case Sky::Cloud:
        paint(cloud, step % 16 >= 8 ? 1 : 0);
        break;
      case Sky::Fog: {
        const int drift = fogDrift[(step / 3) % 4];
        paint(fogUpper, drift);
        paint(fogLower, -drift);
        break;
      }
      case Sky::Rain: {
        paint(wetCloud);
        for (int column = 0; column < 3; ++column) {
          const int fall = (step + column * 2) % 5;
          const int startX = 1 + column * 2;
          const int x = startX + (fall >= 2 ? 1 : 0);
          const int y = 3 + fall;
          if (fall > 0) point(startX + (fall >= 3 ? 1 : 0), y - 1, 54, 92, 220);
          point(x, y, 62, 185, 255);
        }
        break;
      }
      case Sky::Ice:
        paint(wetCloud);
        paint(iceGround);
        for (int column = 0; column < 3; ++column) {
          const int drop = (step / 2 + column) % 4;
          const int x = 1 + column * 2;
          if (drop == 3) {
            point(x, 6, 221, 255, 247);
            point(x + 1, 6, 64, 206, 173);
          } else {
            point(x, 3 + drop, 119, 246, 204);
          }
        }
        break;
      case Sky::Snow:
        paint(snow);
        for (int arm = 0; arm < 6; ++arm) {
          const bool bright = (arm + step / 2) % 3 == 0;
          point(flakeTips[arm][0], flakeTips[arm][1], bright ? 228 : 93,
                bright ? 247 : 150, bright ? 255 : 244);
        }
        break;
      case Sky::Storm:
        paint(wetCloud);
        paint(stormBolt);
        if (step % 12 < 3) {
          point(3, 3, 255, 227, 162);
          point(4, 4, 255, 239, 180);
          point(4, 5, 255, 227, 162);
        }
        break;
      case Sky::Unknown:
        paint(question);
        if (step % 8 < 4) point(3, 6, 149, 245, 235);
        break;
    }
    if (stale) point(7, 7, 255, 91, 24);
    strip.show();
  }

  void pattern(uint32_t elapsed, uint8_t brightness, Pattern theme) {
    reset(brightness);
    const float seconds = elapsed / 1000.0f;
    const auto sample = theme == Pattern::Aurora ? ambient::aurora :
                        theme == Pattern::Ripple ? ambient::ripple : ambient::spiral;
    for (int y = 0; y < 8; ++y) {
      for (int x = 0; x < 8; ++x) {
        const ambient::Light light = sample(x - 3.5f, y - 3.5f, seconds);
        point(x, y, ambient::channel(light.r),
              ambient::channel(light.g), ambient::channel(light.b));
      }
    }
    strip.show();
  }

  void customFrame(const uint8_t (&colors)[64][3], uint8_t brightness) {
    reset(brightness);
    for (int row = 0; row < 8; ++row) {
      for (int column = 0; column < 8; ++column) {
        const auto& rgb = colors[row * 8 + column];
        point(column, row, rgb[0], rgb[1], rgb[2]);
      }
    }
    strip.show();
  }

  void status(uint32_t now, bool setup, uint8_t brightness) {
    reset(brightness);
    paint(wifi);
    int active = (now / 450) % 3;
    for (int n = 0; n < 3; ++n) {
      if (n == active) point(1 + n * 2, 7, setup ? 126 : 255, setup ? 238 : 165, setup ? 216 : 59);
    }
    strip.show();
  }

  void clock(unsigned hour, unsigned minute, uint8_t brightness) {
    reset(brightness);
    // Ring marks twelve, with one brighter tick for the hour.
    const int ring[12][2] = {{4,0},{6,1},{7,2},{7,4},{7,6},{6,7},
                            {4,7},{2,7},{1,6},{0,4},{1,2},{2,1}};
    for (unsigned n = 0; n < 12; ++n) {
      point(ring[n][0], ring[n][1], n == hour % 12 ? 255 : 60,
            n == hour % 12 ? 190 : 80, n == hour % 12 ? 74 : 123);
    }
    const unsigned dots = minute / 10;
    for (unsigned n = 0; n < dots; ++n) point(2 + n, 4, 94, 199, 220);
    strip.show();
  }

  void diagnostic(uint32_t elapsed, MatrixTest pattern) {
    if (pattern == MatrixTest::White) {
      reset(MAX_BRIGHTNESS);
      strip.fill(strip.Color(255, 255, 255));
      strip.show();
      return;
    }
    reset(26);
    if (pattern == MatrixTest::Scan) {
      strip.setPixelColor((elapsed / 240) % 64, strip.Color(180, 180, 180));
    } else {
      point(0, 0, 255, 0, 0);   // top left: red plus one adjacent red
      point(1, 0, 140, 0, 0);
      point(7, 0, 0, 255, 0);
      point(0, 7, 0, 0, 255);
      point(7, 7, 255, 255, 255);
    }
    strip.show();
  }

 private:
  Adafruit_NeoPixel strip{64, LED_DATA_PIN, NEO_GRB + NEO_KHZ800};

  void reset(uint8_t brightness) {
    strip.clear();
    strip.setBrightness(min(brightness, MAX_BRIGHTNESS));
  }

  void point(int x, int y, uint8_t r, uint8_t g, uint8_t b) {
    if (x < 0 || x >= 8 || y < 0 || y >= 8) return;
    if (MATRIX_ORIGIN == Origin::TopRight || MATRIX_ORIGIN == Origin::BottomRight) x = 7 - x;
    if (MATRIX_ORIGIN == Origin::BottomLeft || MATRIX_ORIGIN == Origin::BottomRight) y = 7 - y;
    if (MATRIX_COLUMNS) {
      const int oldX = x;
      x = y;
      y = oldX;
    }
    if (MATRIX_SERPENTINE && y % 2) x = 7 - x;
    strip.setPixelColor(y * 8 + x, strip.Color(r, g, b));
  }

  void paint(const char* const frame[8], int offsetX = 0) {
    for (int y = 0; y < 8; ++y) {
      for (int x = 0; x < 8; ++x) {
        const char index = frame[y][x];
        if (index == '.') continue;
        const Rgb& rgb = palette[index - 'A'];
        point(x + offsetX, y, rgb.r, rgb.g, rgb.b);
      }
    }
  }

  void paintSun(unsigned step) {
    constexpr uint8_t levels[] = {175, 208, 235, 255};
    for (int y = 0; y < 8; ++y) {
      for (int x = 0; x < 8; ++x) {
        const char shade = sun[y][x];
        if (shade != '.') amber(x, y, levels[shade - '0']);
      }
    }
    for (int ray = 0; ray < 8; ++ray) {
      const bool bright = (ray % 2 == 0) == (step % 8 < 4);
      amber(sunRays[ray][0], sunRays[ray][1], bright ? 242 : 128);
    }
  }

  void amber(int x, int y, uint8_t level) {
    point(x, y, level, level * 63 / 100, level / 10);
  }

  struct Rgb { uint8_t r, g, b; };
  // Warm highlights, cool shadows, and enough value separation for the diffuser.
  static constexpr Rgb palette[] = {
    {255, 152, 57},  // A  amber
    {97, 148, 235},  // B  blue
    {160, 194, 235}, // C  pale blue
    {72, 73, 141},   // D  indigo
    {84, 152, 166},  // E  mist shadow
    {146, 215, 220}, // F  lit mist
    {93, 214, 180},  // G  mint
    {255, 229, 151}, // H  warm highlight
    {222, 255, 244}, // I  ice white
    {247, 168, 66},  // J  lightning amber
    {195, 174, 254}, // K  lavender
    {124, 110, 211}, // L  violet
    {224, 93, 51},   // M  orange shadow
    {254, 199, 78},  // N  gold
    {60, 107, 141},  // O  indicator shadow
    {224, 244, 255}, // P  cloud highlight
    {100, 217, 208}, // Q  teal
  };
  static constexpr int8_t sunRays[8][2] = {
    {3, 0}, {6, 1}, {7, 3}, {6, 6}, {4, 7}, {1, 6}, {0, 4}, {1, 1}
  };
  static constexpr int8_t flakeTips[6][2] = {
    {3, 0}, {5, 1}, {6, 3}, {5, 5}, {3, 6}, {0, 3}
  };
  static constexpr int8_t fogDrift[] = {-1, 0, 1, 0};

  static constexpr const char* sun[8] = {
    "........", "........", "...33...", "..3322..", "..3220..", "...10...", "........", "........"
  };
  static constexpr const char* moon[8] = {
    "..K.....", ".PK.....", ".KL.....", ".KL.....", ".KLL.K..", "..LKKL..", "...LL...", "........"
  };
  static constexpr const char* smallSun[8] = {
    "..A.....", ".HNNA...", ".HNNM...", "..MM....", "........", "........", "........", "........"
  };
  static constexpr const char* smallMoon[8] = {
    "..P.....", ".KK.....", ".KLP....", "..LL....", "........", "........", "........", "........"
  };
  static constexpr const char* lowCloud[8] = {
    "........", "........", "........", "....PP..", "...PCCP.", "..PCCCC.", "..DCCB..", "........"
  };
  static constexpr const char* cloud[8] = {
    "........", "...PP...", "..PCBP..", ".PPCCCP.", "PCCCCCC.", ".BBCCC..", "..DDDB..", "........"
  };
  static constexpr const char* fogUpper[8] = {
    "........", "..PFFFE.", "........", "........", "........", ".EFFPP..", "........", "........"
  };
  static constexpr const char* fogLower[8] = {
    "........", "........", "........", ".EPPFFE.", "........", "........", "..EEFF..", "........"
  };
  static constexpr const char* wetCloud[8] = {
    "...PP...", "..PCBCC.", ".DCCBDD.", "........", "........", "........", "........", "........"
  };
  static constexpr const char* iceGround[8] = {
    "........", "........", "........", "........", "........", "........", "........", ".GIGGI.."
  };
  static constexpr const char* snow[8] = {
    "...B....", ".P.B.P..", "..CPC...", "BBCPCBB.", "..CPC...", ".D.B.D..", "...B....", "........"
  };
  static constexpr const char* stormBolt[8] = {
    "........", "........", "........", "...HJ...", "..HJ....", "..JHHA..", "...JA...", "..J....."
  };
  static constexpr const char* question[8] = {
    "..PPQ...", ".Q...Q..", "....QQ..", "...QQ...", "...O....", "........", "...Q....", "........"
  };
  static constexpr const char* wifi[8] = {
    "..QQQQ..", ".Q....Q.", "........", "..OQQO..", "........", "...PP...", "........", ".O.O.O.."
  };
};
