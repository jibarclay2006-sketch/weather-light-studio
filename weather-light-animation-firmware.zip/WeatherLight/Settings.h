#pragma once
#include <Arduino.h>

constexpr int LED_DATA_PIN = 3;  // XIAO D1
constexpr int MODE_PIN = 4;      // XIAO D2
constexpr int OLED_SDA = 6;      // XIAO D4
constexpr int OLED_SCL = 7;      // XIAO D5
constexpr uint8_t MAX_BRIGHTNESS = 48;  // Keep at or below 48 with this power design.
constexpr uint8_t DAY_BRIGHTNESS = 38;
constexpr uint8_t NIGHT_BRIGHTNESS = 10;
static_assert(MAX_BRIGHTNESS <= 48, "The matrix power design requires a 48/255 brightness limit.");

// Origin as seen from the front, with the display upright.
enum class Origin { TopLeft, TopRight, BottomLeft, BottomRight };
constexpr Origin MATRIX_ORIGIN = Origin::TopLeft;
constexpr bool MATRIX_COLUMNS = false;
constexpr bool MATRIX_SERPENTINE = true;

constexpr char DEFAULT_PLACE[] = "Chicago, IL";
constexpr float DEFAULT_LAT = 41.8781f;
constexpr float DEFAULT_LON = -87.6298f;
constexpr char LOCAL_TZ[] = "CST6CDT,M3.2.0/2,M11.1.0/2";
constexpr char FORECAST_TZ[] = "America%2FChicago";
